import string


def print_numbers():
    """
    Prints the digits on a single line in ascending order.
    """
    print(string.digits)

def main():
    print_numbers()

if __name__ == "__main__":
    main()