
import string

def print_alphabet():
    """
    Prints the lowercase alphabet on a single line, in ascending order.
    """
    alphabet = string.ascii_lowercase
    print(alphabet)

def main():
    print_alphabet()


if __name__=="__main__":
    main()